package com.kafka.kafka_demo.kafka;

import org.apache.kafka.common.protocol.Message;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class Producer {
//kafka template will use
	private KafkaTemplate<String, String> kafkaTemplate;
	
	public Producer(KafkaTemplate<String, String> kafkaTemplate) {
		this.kafkaTemplate=kafkaTemplate;
	}
	public void sendMessage(String message){
		
		log.info("mesaage data: {}" ,message);
		kafkaTemplate.send("deepali", message);
	}
}
