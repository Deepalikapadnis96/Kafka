package com.kafka.kafka_demo.kafka;

import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;

import com.kafka.kafka_demo.payload.Users;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class JsonKafkaProducer {

	public KafkaTemplate<String, Users> kafkaTemplate;

	public JsonKafkaProducer(KafkaTemplate<String, Users> kafkaTemplate) {
		this.kafkaTemplate = kafkaTemplate;
	}

	public void sendMessage(Users users) {
		
		log.info("json message send >>{} , users {}", users.toString(),users);
		Message<Users> message = MessageBuilder.withPayload(users)
				.setHeader(KafkaHeaders.TOPIC, "json_topic").build();
		
		kafkaTemplate.send(message);
	}
}
