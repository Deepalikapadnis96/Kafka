package com.kafka.kafka_demo.kafka;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.kafka.kafka_demo.payload.Users;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class JsonKafkaConsumer {
	@KafkaListener(topics = "json_topic", groupId = "MyGroup")
	public void consume(Users user) {
		log.info("message received from json consume method>> {}" , user.toString());
	}
}
