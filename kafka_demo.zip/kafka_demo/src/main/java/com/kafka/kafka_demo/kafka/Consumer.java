package com.kafka.kafka_demo.kafka;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class Consumer {
	@KafkaListener(topics = "deepali", groupId = "MyGroup")
	public void consume(String message) {
		log.info("message received from consume method>> {}" , message);
	}
}
